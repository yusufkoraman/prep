import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { Http } from '@angular/http';
import { DevicePropertyContainer ,CommonListItem} from '../../common';
import { navigationCancelingError } from '@angular/router/src/shared';
@Component({
    selector: 'monitoring',
    templateUrl: './monitoring.component.html'
})
export class MonitoringComponent implements OnInit, OnDestroy {

    performanceItems:string;
    browserSupport:boolean=false;
    memoryInfo:any;
    ngOnInit(): void {
        if (typeof (window.performance) != 'undefined') {
            this.browserSupport=true;
            this.performanceItems=JSON.stringify(window.performance);
            this.memoryInfo=eval("window.performance.memory");
            alert(JSON.stringify(this.memoryInfo));
        }
    }

    ngOnDestroy(): void {

    }

}


