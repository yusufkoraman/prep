/// <reference path="../../../../types/w3c-web-usb/index.d.ts" />
import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { Http } from '@angular/http';
import{LocationInfo} from '../../common';

@Component({
    selector: 'location',
    templateUrl: './location.component.html'
})
    export class LocationComponent implements OnInit, OnDestroy {

    consoleLogs: Array<string> = new Array<string>();
    currentLocation:LocationInfo=new LocationInfo();
    isLoaded:boolean=false;
    intId:number=0;
    isBrowserSupported:boolean=false;

    ngOnInit(): void {
        this.isBrowserSupported=typeof(navigator.geolocation)!='undefined';
        this.isLoaded=false;
        if (!this.isBrowserSupported) {
            return;
        }
        if( this.getLocation()){
            this.intId=setInterval(() => {
                this.isLoaded=false;
           this.getLocation();
        },5000);
        }
    }

    getLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((pos)=>{
                this.currentLocation.lat=pos.coords.latitude;
                this.currentLocation.lng=pos.coords.longitude;
                this.currentLocation.alt=pos.coords.altitude;
                this.currentLocation.timestamp= pos.timestamp;
                this.isLoaded=true;
            });
            return true;
        } else {
            this.consoleLogs.push("Geolocation is not supported by this browser.");
            return false;
        }
    }

    ngOnDestroy(): void {
        if(this.intId>0)
        clearInterval(this.intId);
    }
}