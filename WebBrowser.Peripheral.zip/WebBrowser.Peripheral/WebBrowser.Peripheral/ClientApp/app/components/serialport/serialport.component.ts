import { Component, Inject } from '@angular/core';
import { Http } from '@angular/http';

@Component({
    selector: 'serial-port',
    templateUrl: './serialport.component.html'
})
export class SerialportComponent {

}
