/// <reference path="../../../../types/w3c-web-usb/index.d.ts" />
import { Component, Inject, OnInit, OnDestroy } from '@angular/core';
import { Http } from '@angular/http';
import { DevicePropertyContainer } from '../../common';
@Component({
    selector: 'usb-port',
    templateUrl: './usb-port.component.html'
})
export class UsbPortComponent implements OnInit, OnDestroy {

    devicePropertiesKeys: Array<DevicePropertyContainer>;
    consoleLogs: Array<string> = new Array<string>();
    deviceList: Array<USBDevice>;
    selectedDevice: USBDevice;
    browserSupport:boolean=true;
    ngOnInit(): void {
        if(navigator.usb){
            navigator.usb.addEventListener("connect", event => this.onDeviceConnect(event));
            navigator.usb.addEventListener("disconnect", event => this.onDeviceDisconnected(event));
            this.requestDeviceList();
        }else
            this.browserSupport=false;
    }

    ngOnDestroy(): void {
        if(this.browserSupport){
        navigator.usb.removeEventListener("connect");
            navigator.usb.removeEventListener("disconnect");
            }
    }

    onDeviceConnect(evt: Event) {
        alert("On Device Connected:"+evt.type);
    }
    onDeviceDisconnected(evt: Event) {
        alert("On Device Disconnected:"+evt.type);
    }

    onsendMessageClick() {
        if (this.selectedDevice) {
            this.selectedDevice.open().then(() => this.selectedDevice.selectConfiguration(1))// // Select configuration #1 for the device.
                .then(() => this.selectedDevice.claimInterface(2))//// Request exclusive control over interface #2.
                .then(() => this.selectedDevice.controlTransferOut(
                    {
                        requestType: 'class',
                        recipient: 'interface',
                        request: 0x22,
                        value: 0x01,
                        index: 0x02
                    }));
        }
    }

    ongetMessageClick() {
        let result = this.selectedDevice.transferIn(5, 64); // Waiting for 64 bytes of data from endpoint #5.
        //let decoder = new TextDecoder();
        //document.getElementById('target').innerHTML = 'Received: ' + decoder.decode(result.data);
    }



    requestDeviceList(): void {
      this.devicePropertiesKeys = new Array<DevicePropertyContainer>();
        navigator.usb.requestDevice({ filters: [{}] }).then(device => {
            this.deviceList = new Array<USBDevice>();
            this.deviceList.push(device);
            this.selectedDevice = device;
            this.onDeviceSelection(device);
            });
    }
    onDeviceSelection(sel: USBDevice) {
        this.devicePropertiesKeys=new Array<DevicePropertyContainer>();
        this.devicePropertiesKeys.push(new DevicePropertyContainer("deviceClass", this.selectedDevice.deviceClass));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("deviceProtocol", this.selectedDevice.deviceProtocol));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("deviceSubclass", this.selectedDevice.deviceSubclass));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("deviceVersionMajor", this.selectedDevice.deviceVersionMajor));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("deviceVersionMinor", this.selectedDevice.deviceVersionMinor));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("deviceVersionSubminor", this.selectedDevice.deviceVersionSubminor));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("manufacturerName", this.selectedDevice.manufacturerName));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("opened", this.selectedDevice.opened));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("productId", this.selectedDevice.productId));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("productName", this.selectedDevice.productName));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("serialNumber", this.selectedDevice.serialNumber));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("usbVersionMajor", this.selectedDevice.usbVersionMajor));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("usbVersionMinor", this.selectedDevice.usbVersionMinor));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("usbVersionSubminor", this.selectedDevice.usbVersionSubminor));
        this.devicePropertiesKeys.push(new DevicePropertyContainer("vendorId", this.selectedDevice.vendorId));
        this.consoleLogs.push("Device properties readed");
    }


    getDevices(): void {
        this.devicePropertiesKeys = new Array<DevicePropertyContainer>();
        navigator.usb.getDevices().then(devices => {
            this.deviceList = new Array<USBDevice>();
            devices.map(device => {
                this.deviceList.push(device);
                this.consoleLogs.push("Device properties readed");
            });
            if (this.deviceList.length > 0) {
                let dev = this.deviceList[0];
                this.onDeviceSelection(dev);
            }
        }).catch(err => {
            this.consoleLogs.push("getDevices error" + err.message);
        });
    }

    openSocket() {
        if (this.selectedDevice != null) {
            this.selectedDevice.open().then(() => {
                this.consoleLogs.push("Device opened");
            }).catch(e => {
                this.consoleLogs.push("Device open error:" + e.message);
            });

        }
    }
}

