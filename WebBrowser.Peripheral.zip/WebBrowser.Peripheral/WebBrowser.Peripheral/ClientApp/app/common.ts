﻿export class DevicePropertyContainer {
    key: string;
    value: string | number | undefined | boolean;

    constructor(_key: string, _value: string | number | undefined | boolean) {
        this.key = _key
        this.value = _value;
    }
    
}

export class LocationInfo {
    lat:any;
    lng:any;
    alt:any;
    timestamp:any;
}

export class CommonListItem {
    constructor(_key: any, _value: any) {
        this.key=_key;
        this.value=_value;
    }
    key:any;
    value:any;
}
